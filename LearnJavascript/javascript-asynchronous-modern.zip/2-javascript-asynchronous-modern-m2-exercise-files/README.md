This is a starting point for my Pluralsight course "Modern Asynchronous JavaScript"
