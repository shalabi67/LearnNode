setTimeout(
  () => {
    console.log('Hello after 4 seconds');
  },
  4 * 1000
);
