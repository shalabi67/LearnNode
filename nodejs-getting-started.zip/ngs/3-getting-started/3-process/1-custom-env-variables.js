console.log('Current user is', process.env.USER);

console.log('\nScript executed with:');

console.log('VAL1 equalt to:', process.env.VAL1);
console.log('VAL2 equalt to:', process.env.VAL2);
