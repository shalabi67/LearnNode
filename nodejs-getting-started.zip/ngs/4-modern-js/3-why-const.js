const answer = 42;

/*

A big program here...

*/

answer // is still 42;



// vs



let answer = 42;

/*

A big program here...

*/

answer // might have changed;
