const lodash = require('lodash');

const sum = lodash.sum([1, 2, 4, 5, 6, 7, 8, 9, 10]);

console.log('Sum is', sum);
