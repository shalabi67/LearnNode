test('Math.sqrt', () => {
  expect(Math.sqrt(9)).toBe(3);
});
