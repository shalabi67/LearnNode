const moduleApi = require('./3-wrapper');

console.log(moduleApi);
