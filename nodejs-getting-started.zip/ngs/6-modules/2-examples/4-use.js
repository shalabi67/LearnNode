const templateGenerator = require('./4-function');

const myTemplate = templateGenerator('Hello Node!');

console.log(myTemplate);
